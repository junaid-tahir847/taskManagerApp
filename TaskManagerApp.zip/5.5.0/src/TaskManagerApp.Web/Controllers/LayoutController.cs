namespace TaskManagerApp.Web.Controllers
{
    public class LayoutController : TaskManagerAppControllerBase
    {

    }
}