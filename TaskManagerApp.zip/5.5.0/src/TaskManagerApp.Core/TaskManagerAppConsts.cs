﻿namespace TaskManagerApp
{
    public class TaskManagerAppConsts
    {
        public const string LocalizationSourceName = "TaskManagerApp";

        public const string ConnectionStringName = "Default";
    }
}